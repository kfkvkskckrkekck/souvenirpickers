import{s as e}from"./core-components-DYNf2W7R.js";async function n(i,s=""){const{data:{user:t}}=await e.auth.getUser();if(!t)throw new Error("Must be logged in to add to wishlist");const{data:r,error:a}=await e.from("wishlists").insert({user_id:t.id,listing_id:i,notes:s}).select().single();if(a)throw a;return r}async function d(i){const{data:{user:s}}=await e.auth.getUser();if(!s)throw new Error("Must be logged in to remove from wishlist");const{error:t}=await e.from("wishlists").delete().eq("user_id",s.id).eq("listing_id",i);if(t)throw t}async function u(){const{data:{user:i}}=await e.auth.getUser();if(!i)return[];const{data:s,error:t}=await e.from("wishlists").select(`
      *,
      listing:listings(
        *,
        picker:profiles!listings_picker_id_fkey(
          id,
          full_name,
          avatar_url,
          trust_score
        )
      )
    `).eq("user_id",i.id).order("created_at",{ascending:!1});return t?[]:s}async function l(i){const{data:{user:s}}=await e.auth.getUser();if(!s)return!1;const{data:t,error:r}=await e.from("wishlists").select("id").eq("user_id",s.id).eq("listing_id",i).maybeSingle();return r?!1:!!t}async function c(i,s){const{data:{user:t}}=await e.auth.getUser();if(!t)throw new Error("Must be logged in to update wishlist");const{error:r}=await e.from("wishlists").update({notes:s}).eq("user_id",t.id).eq("listing_id",i);if(r)throw r}export{n as a,u as g,l as i,d as r,c as u};
